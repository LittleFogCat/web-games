# VECTOR // 矢界防线 — 静态部署包

**版本：1.0.0**  
**类型：纯静态网页游戏 / 竖版深空塔防**

本目录是完整可运行版本，不需要 Node.js、不需要构建步骤，也不需要后端服务。将目录内全部文件上传到任意静态站点根目录或子目录即可。

## 包内文件

```text
index.html       页面入口
styles.css       全部界面与响应式样式
src/             游戏运行时代码（7 个 JavaScript 文件）
.nojekyll        供 GitHub Pages 使用，阻止 Jekyll 处理
README.md        本说明
```

所有塔、敌人、图标、弹道、特效、星空与 UI 图形均由 Canvas / CSS 程序化绘制；音频由 Web Audio 实时合成。**没有外部图片、字体、音频或 CDN 依赖。**

## 部署

### 通用静态托管 / Nginx / Apache

把本目录中的文件放到网站目录，例如：

```text
/var/www/html/index.html
/var/www/html/styles.css
/var/www/html/src/*.js
```

确保服务器将 `.js` 返回为 `text/javascript`、`.css` 返回为 `text/css`。游戏使用相对路径，可以部署在根路径，也可以部署在 `/games/vector/` 这样的子目录。

### Netlify / Vercel / Cloudflare Pages

- 创建静态站点；
- Build command 留空；
- Publish / Output directory 填本目录；
- 部署即可。

### GitHub Pages

把本目录作为 Pages 发布目录，或在仓库根目录发布。`.nojekyll` 已包含在包内。

### 本地验证

```powershell
python -m http.server 8080 --bind 127.0.0.1
```

访问 `http://127.0.0.1:8080/`。也可以直接双击 `index.html` 游玩。

> 如果通过反向代理挂载到子路径，请保留末尾斜杠（例如 `/games/vector/`），以确保相对资源路径正确解析。

## 运行要求

- 支持 Canvas 2D、ES2018、CSS `dvh`/`color-mix` 的现代浏览器；
- 推荐移动端 Safari 16.2+、Chrome 111+、Edge 111+ 或更新版本；
- 游戏进度保存在浏览器 `localStorage`，换域名或清理站点数据会重置进度；
- 不需要联网，不含外部 API 请求。

## 玩法

- 选择关卡，建造防御塔与偏折壁垒，守住底部星域核心；
- 7 种塔：棱镜箭塔、矢量机炮、引力重炮、相干激光、谐振震荡塔、熵减冻结塔、链式电弧塔，每种 5 级；
- 晶元由击杀获得，用于局内建造、升级与回收；
- 完成关卡获得金币，用于 7 条五阶全局技能；
- 10 个关卡、多种敌人、第 10 关最终首领；
- 防御塔与壁垒都会阻挡并迫使敌人重新寻路，但不能封死全部通路。

详细操作、敌情与项目结构请见开发目录中的 `README.md`。
